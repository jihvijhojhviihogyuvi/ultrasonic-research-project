#ifndef ATOM_LINEAR_H
#define ATOM_LINEAR_H

#include "common.h"

static PyObject *py_make_linear(PyObject *self, PyObject *args)
{
    PyObject *child_capsule;
    PyObject *data_obj, *indices_obj, *indptr_obj;
    PyObject *b_obj = Py_None; /* Optional offset vector */
    int m, n;

    /* Accept optional b array: (child, data, indices, indptr, m, n[, b]) */
    if (!PyArg_ParseTuple(args, "OOOOii|O", &child_capsule, &data_obj, &indices_obj,
                          &indptr_obj, &m, &n, &b_obj))
    {
        return NULL;
    }

    expr *child = (expr *) PyCapsule_GetPointer(child_capsule, EXPR_CAPSULE_NAME);
    if (!child)
    {
        PyErr_SetString(PyExc_ValueError, "invalid child capsule");
        return NULL;
    }

    PyArrayObject *data_array =
        (PyArrayObject *) PyArray_FROM_OTF(data_obj, NPY_DOUBLE, NPY_ARRAY_IN_ARRAY);
    PyArrayObject *indices_array = (PyArrayObject *) PyArray_FROM_OTF(
        indices_obj, NPY_INT32, NPY_ARRAY_IN_ARRAY);
    PyArrayObject *indptr_array = (PyArrayObject *) PyArray_FROM_OTF(
        indptr_obj, NPY_INT32, NPY_ARRAY_IN_ARRAY);

    if (!data_array || !indices_array || !indptr_array)
    {
        Py_XDECREF(data_array);
        Py_XDECREF(indices_array);
        Py_XDECREF(indptr_array);
        return NULL;
    }

    int nnz = (int) PyArray_SIZE(data_array);
    CSR_matrix *A = new_CSR_matrix(m, n, nnz);
    memcpy(A->x, PyArray_DATA(data_array), nnz * sizeof(double));
    memcpy(A->i, PyArray_DATA(indices_array), nnz * sizeof(int));
    memcpy(A->p, PyArray_DATA(indptr_array), (m + 1) * sizeof(int));

    Py_DECREF(data_array);
    Py_DECREF(indices_array);
    Py_DECREF(indptr_array);

    /* Parse optional b offset vector */
    double *b_data = NULL;
    PyArrayObject *b_array = NULL;

    if (b_obj != Py_None)
    {
        b_array = (PyArrayObject *) PyArray_FROM_OTF(b_obj, NPY_DOUBLE,
                                                     NPY_ARRAY_IN_ARRAY);
        if (!b_array)
        {
            free_CSR_matrix(A);
            return NULL;
        }
        b_data = (double *) PyArray_DATA(b_array);
    }

    expr *node = new_linear(child, A, b_data);

    /* Clean up */
    free_CSR_matrix(A);
    Py_XDECREF(b_array);

    if (!node)
    {
        PyErr_SetString(PyExc_RuntimeError, "failed to create linear node");
        return NULL;
    }
    expr_retain(node); /* Capsule owns a reference */
    return PyCapsule_New(node, EXPR_CAPSULE_NAME, expr_capsule_destructor);
}

#endif /* ATOM_LINEAR_H */
