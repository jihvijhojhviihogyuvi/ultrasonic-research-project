"""
Copyright 2013 Steven Diamond

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from cvxpy.atoms.sum_largest import sum_largest
from cvxpy.expressions.expression import Expression


def sum_smallest(x, k, axis=None, keepdims=False):
    """Sum of the smallest k values, optionally along an axis.
    """
    x = Expression.cast_to_const(x)
    return -sum_largest(-x, k, axis=axis, keepdims=keepdims)
